from flask import Flask, request, jsonify, render_template, send_from_directory, url_for
import requests
import cohere
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures
from azure.core.credentials import AzureKeyCredential
from azure.ai.textanalytics import TextAnalyticsClient, ExtractiveSummaryAction
import uuid
import base64
import logging
import os
import io
from io import BytesIO
from PIL import Image

app = Flask(__name__)

# API Configurations
BING_API_KEY = "YOUR_BING_API_KEY"
COHERE_API_KEY = "YOUR_COHERE_API_KEY"
VISION_ENDPOINT = "YOUR_VISION_ENDPOINT"
VISION_KEY = "YOUR_VISION_KEY"
TEXT_ANALYTICS_KEY = "YOUR_TEXT_ANALYTICS_KEY"
TEXT_ANALYTICS_ENDPOINT = "YOUR_TEXT_ANALYTICS_ENDPOINT"
TRANSLATOR_KEY = "YOUR_TRANSLATOR_API_KEY"
TRANSLATOR_ENDPOINT = "https://api.cognitive.microsofttranslator.com"
LOCATION = "YOUR_LOCATION"

# Routes
@app.route('/')
def home():
    return render_template('index.html')
# Bing Web Search
search_url = "https://api.bing.microsoft.com/v7.0/search"
def bing_web_search(search_term):
    headers = {"Ocp-Apim-Subscription-Key": BING_API_KEY}
    params = {"q": search_term, "textDecorations": True, "textFormat": "HTML"}
    try:
        response = requests.get(search_url, headers=headers, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": str(e)}

@app.route('/bing_search', methods=['POST'])
def bing_search():
    query = request.json.get('query', '')
    if not query:
        return jsonify({"error": "Query parameter is required."}), 400
    
    results = bing_web_search(query)
    if "error" in results:
        return jsonify({"error": results["error"]}), 500

    formatted_results = {
        "query": query,
        "results": [
            {
                "title": v.get("name"),
                "url": v.get("url"),
                "snippet": v.get("snippet")
            }
            for v in results.get("webPages", {}).get("value", [])
        ]
    }

    return jsonify(formatted_results)


# Cohere Chat
@app.route('/cohere_chat', methods=['POST'])
def cohere_chat():
    prompt = request.json.get('prompt', '')
    if not prompt:
        return jsonify({"error": "Prompt is required."}), 400
    try:
        co = cohere.ClientV2(api_key=COHERE_API_KEY)
        response = co.chat(model="command-r-plus-08-2024", messages=[{"role": "user", "content": prompt}])
        return jsonify({"response": response.message.content[0].text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Summarization
from azure.ai.textanalytics import TextAnalyticsClient, ExtractiveSummaryAction
from azure.core.credentials import AzureKeyCredential

# Authenticate the Text Analytics client
def authenticate_client():
    ta_credential = AzureKeyCredential(TEXT_ANALYTICS_KEY)
    text_analytics_client = TextAnalyticsClient(
        endpoint=TEXT_ANALYTICS_ENDPOINT,
        credential=ta_credential
    )
    return text_analytics_client

client = authenticate_client()

@app.route('/summarize', methods=['POST'])
def summarize():
    try:
        # Log that the request is received
        print("Summarize request received.")

        # Get the text from the request JSON
        request_data = request.get_json()
        text = request_data.get('text', '')

        # Validate the input
        if not text:
            return jsonify({"error": "Text is required for summarization."}), 400

        # Prepare the text as a list (expected by the Azure API)
        documents = [text]

        # Begin summarization action
        print("Starting summarization...")
        poller = client.begin_analyze_actions(
            documents,
            actions=[
                ExtractiveSummaryAction(max_sentence_count=4)
            ],
        )

        # Wait for the result
        document_results = poller.result()
        print("Summarization complete.")

        # Extract the summary
        for document_result in document_results:
            extract_summary_result = document_result[0]
            if extract_summary_result.is_error:
                error_message = f"Error with code '{extract_summary_result.code}' and message '{extract_summary_result.message}'"
                print(error_message)
                return jsonify({"error": error_message}), 500
            else:
                summary = " ".join([sentence.text for sentence in extract_summary_result.sentences])
                print("Summary:", summary)
                return jsonify({"summary": summary})

    except Exception as e:
        print(f"An error occurred: {e}")
        return jsonify({"error": str(e)}), 500

# Translation
@app.route('/translate', methods=['POST'])
def translate():
    data = request.json
    text = data.get('text', '')
    target_langs = data.get('languages', ['hi', 'fr', 'es'])
    if not text:
        return jsonify({"error": "Text is required for translation."}), 400
    try:
        params = {'api-version': '3.0', 'to': target_langs}
        headers = {
            'Ocp-Apim-Subscription-Key': TRANSLATOR_KEY,
            'Ocp-Apim-Subscription-Region': LOCATION,
            'Content-type': 'application/json',
            'X-ClientTraceId': str(uuid.uuid4())
        }
        body = [{'text': text}]
        response = requests.post(TRANSLATOR_ENDPOINT + '/translate', params=params, headers=headers, json=body)
        response.raise_for_status()
        return jsonify(response.json())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)