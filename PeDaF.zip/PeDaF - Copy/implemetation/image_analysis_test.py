import os
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import HttpResponseError

# Retrieve endpoint and key from environment variables
endpoint = os.getenv("VISION_ENDPOINT", "YOUR_VISION_ENDPOINT")
key = os.getenv("VISION_KEY", "YOUR_VISION_KEY")

if not endpoint or not key:
    print("Missing 'VISION_ENDPOINT' or 'VISION_KEY'. Set them as environment variables.")
    exit()

# Create an Image Analysis client
client = ImageAnalysisClient(
    endpoint=endpoint,
    credential=AzureKeyCredential(key)
)

try:
    # Analyze the image
    result = client.analyze_from_url(
        image_url="https://learn.microsoft.com/azure/ai-services/computer-vision/media/quickstarts/presentation.png",
        visual_features=[VisualFeatures.READ],  # Removed VisualFeatures.CAPTION for unsupported regions
        gender_neutral_caption=False,  # Optional, defaults to False
    )

    print("Image analysis results:")
    # Print text (OCR) analysis results to the console
    if result.read is not None:
        print(" Read:")
        for block in result.read.blocks:
            for line in block.lines:
                print(f"   Line: '{line.text}', Bounding box: {line.bounding_polygon}")
                for word in line.words:
                    print(f"     Word: '{word.text}', Bounding polygon: {word.bounding_polygon}, Confidence: {word.confidence:.4f}")

except HttpResponseError as e:
    print(f"HTTP Response Error: {e.message}")
except Exception as e:
    print(f"Unexpected Error: {e}")
