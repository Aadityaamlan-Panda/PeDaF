import requests

# Define your subscription key and endpoint
subscription_key = "BING_API_KEY"  # Replace with your Bing Search API subscription key
assert subscription_key, "Subscription key is required."

# Bing Web Search API endpoint
search_url = "https://api.bing.microsoft.com/v7.0/search"

# Define the search term
search_term = "Microsoft Bing Search Services"

# Function to perform a Bing Web Search
def bing_web_search(search_term):
    """
    Perform a Bing Web Search and return the results.
    Args:
        search_term (str): The query to search for.
    Returns:
        dict: The search results in JSON format.
    """
    headers = {"Ocp-Apim-Subscription-Key": subscription_key}
    params = {"q": search_term, "textDecorations": True, "textFormat": "HTML"}
    
    try:
        # Send a GET request to the Bing Web Search API
        response = requests.get(search_url, headers=headers, params=params)
        response.raise_for_status()  # Raise an exception for HTTP errors
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return None

# Perform the search
search_results = bing_web_search(search_term)

# Display the results
if search_results:
    try:
        print("Search Results:")
        for v in search_results.get("webPages", {}).get("value", []):
            print(f"- Title: {v['name']}")
            print(f"  URL: {v['url']}")
            print(f"  Snippet: {v['snippet']}\n")
    except KeyError:
        print("No web pages found in the search results.")
else:
    print("No search results returned.")
